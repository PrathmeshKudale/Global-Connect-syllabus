# 💰 AI-Powered Personal Finance Assistant

A full-stack hackathon-ready web app for tracking expenses, managing budgets, and getting AI-powered financial insights.

---

## 🚀 Tech Stack

| Layer       | Technology                        |
|-------------|-----------------------------------|
| Frontend    | React 18 + Vite + Tailwind CSS    |
| State       | Zustand + React Query             |
| Backend     | Node.js + Express.js              |
| Database    | MongoDB Atlas (Mongoose)          |
| Auth        | JWT + Firebase Auth               |
| AI / LLM    | OpenAI GPT-4o                     |
| OCR         | Tesseract.js                      |
| Voice       | Web Speech API + Whisper API      |
| Email       | Nodemailer / SendGrid             |
| Deployment  | Vercel (frontend) + Render (API)  |

---

## 📁 Project Structure

```
financeapp/
├── backend/          Node.js + Express API
│   ├── src/
│   │   ├── config/   DB connection + seed data
│   │   ├── models/   User, Expense, Category, Budget
│   │   ├── routes/   auth, expenses, budgets, insights, chat
│   │   ├── controllers/
│   │   ├── middleware/ JWT auth, file upload
│   │   └── services/ OpenAI, OCR, notifications + cron jobs
│   └── server.js
└── frontend/         React + Vite SPA
    └── src/
        ├── pages/    Auth, Dashboard, AddExpense, History,
        │             Insights, Budgets, Chat, Settings
        ├── components/layout, charts, ui
        ├── services/ Axios API calls
        ├── store/    Zustand auth store
        └── utils/    Formatters, helpers
```

---

## ⚡ Quick Start

### 1. Clone and install

```bash
# Backend
cd backend
npm install
cp .env.example .env    # Fill in your keys

# Frontend
cd ../frontend
npm install
cp .env.example .env    # Fill in VITE_API_URL
```

### 2. Set up MongoDB

- Create a free cluster at [mongodb.com/atlas](https://mongodb.com/atlas)
- Copy the connection string into `backend/.env` → `MONGODB_URI`

### 3. Seed default categories

```bash
cd backend
npm run seed
```

### 4. Run development servers

```bash
# Terminal 1 — Backend (port 5000)
cd backend && npm run dev

# Terminal 2 — Frontend (port 5173)
cd frontend && npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## 🔑 Required API Keys

| Service       | Where to get                          | Used for                    |
|---------------|---------------------------------------|-----------------------------|
| MongoDB Atlas | mongodb.com/atlas                     | Database                    |
| OpenAI        | platform.openai.com/api-keys          | GPT-4o insights + chat      |
| Firebase      | console.firebase.google.com           | Auth + file storage         |
| Cloudinary    | cloudinary.com (optional)             | Receipt image hosting       |
| SendGrid      | sendgrid.com (optional)               | Budget alert emails         |

---

## 🌐 API Reference

Base URL: `POST /api/v1`  
All routes except `/auth/*` require `Authorization: Bearer <token>`

```
POST   /auth/register          Create account
POST   /auth/login             Sign in
GET    /auth/me                Get current user
PATCH  /auth/profile           Update profile

GET    /expenses               List (paginated, filterable)
POST   /expenses               Add expense (AI categorizes)
POST   /expenses/voice         Parse voice transcript
POST   /expenses/receipt       OCR receipt scan
DELETE /expenses/:id           Delete expense
GET    /expenses/summary       Category totals for period

GET    /budgets                List with progress
POST   /budgets                Create budget
PATCH  /budgets/:id            Update budget
DELETE /budgets/:id            Delete budget

GET    /insights               AI-generated spending insights
GET    /insights/anomalies     Unusual transactions
GET    /insights/trends        Weekly trend data

POST   /chat/query             AI chatbot query
```

---

## 🚢 Deployment

**Frontend → Vercel**
```bash
cd frontend && npx vercel --prod
# Set VITE_API_URL to your Render backend URL
```

**Backend → Render**
- Connect GitHub repo, select `backend/` as root
- Set all environment variables in Render dashboard
- Start command: `npm start`

---

## ✨ Features

- ✅ Manual expense entry with category picker
- ✅ Voice input via Web Speech API + GPT parsing
- ✅ Receipt OCR scanning with Tesseract.js
- ✅ AI auto-categorization using GPT-4o
- ✅ AI insights + anomaly detection
- ✅ Budget management with alerts
- ✅ Contextual AI chatbot (knows your actual data)
- ✅ Weekly digest emails + budget alert notifications
- ✅ Export to CSV
- ✅ JWT authentication
- ✅ Responsive dark-theme UI
