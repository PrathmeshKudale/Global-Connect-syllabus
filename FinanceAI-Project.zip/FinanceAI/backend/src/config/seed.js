const dotenv = require('dotenv');
dotenv.config({ path: '../../.env' });
const connectDB = require('./db');
const Category = require('../models/Category');

const DEFAULT_CATEGORIES = [
  { name: 'Food & Dining',   icon: '🍔', color: '#f59e0b', keywords: ['restaurant','cafe','swiggy','zomato','food','grocery','supermarket','dmart','bigbasket'] },
  { name: 'Transport',       icon: '🚗', color: '#60a5fa', keywords: ['uber','ola','fuel','petrol','metro','bus','cab','rapido','auto','parking'] },
  { name: 'Shopping',        icon: '🛍️', color: '#a78bfa', keywords: ['amazon','flipkart','myntra','ajio','zara','h&m','mall','clothes','shoes'] },
  { name: 'Entertainment',   icon: '🎬', color: '#f472b6', keywords: ['netflix','spotify','prime','hotstar','cinema','movie','concert','game'] },
  { name: 'Health',          icon: '💊', color: '#4ade80', keywords: ['pharmacy','doctor','hospital','medicine','clinic','gym','apollo','medplus'] },
  { name: 'Utilities',       icon: '⚡', color: '#22d3ee', keywords: ['electricity','water','gas','internet','wifi','broadband','jio','airtel'] },
  { name: 'Rent & Housing',  icon: '🏠', color: '#fb7185', keywords: ['rent','maintenance','society','landlord','housing'] },
  { name: 'Education',       icon: '📚', color: '#fbbf24', keywords: ['udemy','coursera','book','stationery','tuition','school','college','course'] },
  { name: 'Travel',          icon: '✈️', color: '#34d399', keywords: ['hotel','flight','makemytrip','goibibo','oyo','holiday','trip','travel','airbnb'] },
  { name: 'Personal Care',   icon: '💆', color: '#c084fc', keywords: ['salon','spa','haircut','beauty','cosmetics','nykaa'] },
  { name: 'Investments',     icon: '📈', color: '#6ee7b7', keywords: ['mutual fund','stocks','zerodha','groww','sip','fd','nps','investment'] },
  { name: 'Other',           icon: '📦', color: '#94a3b8', keywords: [] },
];

async function seed() {
  await connectDB();
  await Category.deleteMany({ isDefault: true });
  const cats = DEFAULT_CATEGORIES.map(c => ({ ...c, isDefault: true }));
  await Category.insertMany(cats);
  console.log(`✅ Seeded ${cats.length} default categories`);
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
