const OpenAI = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ── Categorize an expense using GPT ──
exports.categorizeExpense = async (merchant, note, categories) => {
  try {
    const catList = categories.map(c => `${c._id}|${c.name}|${c.keywords.join(',')}`).join('\n');

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      temperature: 0,
      max_tokens: 100,
      messages: [
        {
          role: 'system',
          content: `You are an expense categorization engine. Given a merchant name and note, 
          pick the most appropriate category from the list below. 
          Respond with ONLY the category ID, nothing else.
          
          Categories (format: id|name|keywords):
          ${catList}`,
        },
        {
          role: 'user',
          content: `Merchant: "${merchant}" | Note: "${note}"`,
        },
      ],
    });

    const rawId = completion.choices[0].message.content.trim();
    const matched = categories.find(c => c._id.toString() === rawId);
    // Fallback to "Other" if not matched
    const other = categories.find(c => c.name === 'Other');
    return { categoryId: matched?._id || other?._id, name: matched?.name || 'Other' };
  } catch (err) {
    console.error('categorizeExpense error:', err.message);
    const other = categories.find(c => c.name === 'Other');
    return { categoryId: other?._id, name: 'Other' };
  }
};

// ── Parse a voice transcript into expense fields ──
exports.parseVoiceTranscript = async (transcript, categories) => {
  try {
    const catNames = categories.map(c => c.name).join(', ');
    const today = new Date().toISOString().split('T')[0];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      temperature: 0,
      max_tokens: 200,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `You parse voice expense inputs into structured JSON.
          Today is ${today}. Available categories: ${catNames}.
          
          Return JSON with these fields:
          { "amount": number, "merchant": string, "category": string, "date": "YYYY-MM-DD", "note": string }
          
          Rules:
          - amount: extract the number only (e.g. "250", not "₹250")
          - merchant: the store/service name
          - category: pick from available categories
          - date: infer from context ("yesterday", "last Monday") or use today
          - note: any additional context mentioned`,
        },
        { role: 'user', content: transcript },
      ],
    });

    const parsed = JSON.parse(completion.choices[0].message.content);
    // Match category to ObjectId
    const matched = categories.find(c => c.name.toLowerCase() === parsed.category?.toLowerCase());
    return { ...parsed, categoryId: matched?._id };
  } catch (err) {
    console.error('parseVoiceTranscript error:', err.message);
    return { amount: null, merchant: '', category: 'Other', date: new Date().toISOString().split('T')[0], note: '' };
  }
};

// ── Generate AI insights for a month's spending ──
exports.generateInsights = async ({ currentSummary, prevMap, totalSpent, month, userName, currency }) => {
  try {
    const summaryText = currentSummary.map(c => {
      const prev = prevMap[c._id?.toString()] || 0;
      const delta = prev ? (((c.total - prev) / prev) * 100).toFixed(1) : 'N/A';
      return `${c.icon} ${c.name}: ${currency} ${c.total.toFixed(0)} (${delta}% vs last month, ${c.count} transactions)`;
    }).join('\n');

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      temperature: 0.7,
      max_tokens: 600,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `You are a friendly personal finance advisor. Analyze spending data and return actionable insights in JSON.
          
          Return: { 
            "insights": [{ "title": string, "description": string, "type": "positive"|"warning"|"info", "emoji": string }],
            "tips": [string] 
          }
          
          Be specific with numbers. Be encouraging but honest. Max 4 insights, max 3 tips.`,
        },
        {
          role: 'user',
          content: `User: ${userName} | Month: ${month} | Total spent: ${currency} ${totalSpent.toFixed(0)}
          
          Category breakdown:
          ${summaryText}
          
          Generate personalized insights and saving tips.`,
        },
      ],
    });

    return JSON.parse(completion.choices[0].message.content);
  } catch (err) {
    console.error('generateInsights error:', err.message);
    return { insights: [], tips: ['Track your expenses daily for better insights.'] };
  }
};

// ── Detect spending anomalies ──
exports.detectAnomalies = async (expenses, currency) => {
  try {
    if (expenses.length < 5) return [];

    // Calculate mean and std dev per category
    const byCat = {};
    expenses.forEach(e => {
      const cat = e.categoryId?.name || 'Other';
      if (!byCat[cat]) byCat[cat] = [];
      byCat[cat].push(e.amount);
    });

    const anomalies = [];
    for (const [cat, amounts] of Object.entries(byCat)) {
      if (amounts.length < 3) continue;
      const mean = amounts.reduce((s, a) => s + a, 0) / amounts.length;
      const std = Math.sqrt(amounts.reduce((s, a) => s + Math.pow(a - mean, 2), 0) / amounts.length);
      
      expenses.filter(e => e.categoryId?.name === cat).forEach(e => {
        if (e.amount > mean + 2 * std) {
          anomalies.push({
            expense: e,
            reason: `This ${cat} expense (${currency} ${e.amount.toFixed(0)}) is significantly above your average of ${currency} ${mean.toFixed(0)}`,
          });
        }
      });
    }

    return anomalies.slice(0, 5);
  } catch (err) {
    console.error('detectAnomalies error:', err.message);
    return [];
  }
};

// ── Contextual chatbot ──
exports.chatWithContext = async (message, history, context) => {
  try {
    const systemPrompt = `You are a smart, friendly personal finance assistant for ${context.userName}.
    
    USER'S FINANCIAL CONTEXT (last 90 days):
    - Total spent: ${context.currency} ${context.totalSpentLast90Days?.toFixed(0)}
    - Total transactions: ${context.expenseCount}
    - Spending by category:
    ${Object.entries(context.categoryBreakdown || {}).map(([cat, amt]) => `  • ${cat}: ${context.currency} ${amt?.toFixed(0)}`).join('\n')}
    
    Recent transactions:
    ${context.recentTransactions?.map(t => `  • ${t.date?.toString().slice(0,10)} - ${t.merchant} - ${context.currency} ${t.amount} (${t.category})`).join('\n')}
    
    RULES:
    - Answer questions about their spending with specific numbers from the context above
    - Be concise, warm, and actionable
    - If asked for a chart or comparison, format numbers clearly
    - If you don't have enough data, say so honestly
    - Keep responses under 200 words`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.slice(-10), // Keep last 10 messages for context window
      { role: 'user', content: message },
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      temperature: 0.5,
      max_tokens: 350,
      messages,
    });

    return completion.choices[0].message.content;
  } catch (err) {
    console.error('chatWithContext error:', err.message);
    return 'Sorry, I had trouble processing that. Please try again.';
  }
};
