const Tesseract = require('tesseract.js');

// Extract expense data from a receipt image buffer
exports.extractReceiptData = async (imageBuffer, mimetype) => {
  try {
    const base64 = imageBuffer.toString('base64');
    const dataUri = `data:${mimetype};base64,${base64}`;

    const { data: { text } } = await Tesseract.recognize(dataUri, 'eng', {
      logger: () => {}, // suppress progress logs
    });

    return parseReceiptText(text);
  } catch (err) {
    console.error('OCR error:', err.message);
    return { amount: null, merchant: '', date: null, rawText: '' };
  }
};

// Heuristic parser for common receipt formats
function parseReceiptText(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  // ── Extract Amount ──
  // Look for patterns like: Total: 450.00 | ₹450 | Rs. 450 | TOTAL 450.00
  const amountPatterns = [
    /(?:total|amount|grand total|bill amount|net amount)[:\s]+(?:rs\.?|₹|inr)?\s*([\d,]+\.?\d{0,2})/i,
    /(?:₹|rs\.?|inr)\s*([\d,]+\.?\d{0,2})/i,
    /([\d,]+\.\d{2})(?:\s|$)/,
  ];
  let amount = null;
  for (const pattern of amountPatterns) {
    for (const line of lines) {
      const match = line.match(pattern);
      if (match) {
        amount = parseFloat(match[1].replace(/,/g, ''));
        if (amount > 0) break;
      }
    }
    if (amount) break;
  }

  // ── Extract Merchant ──
  // Typically the first 1-2 non-empty lines are the store name
  const merchantLine = lines.find(l => l.length > 3 && !/^\d/.test(l) && !/gst|tax|total|date|time|bill/i.test(l));
  const merchant = merchantLine ? merchantLine.replace(/[^a-zA-Z0-9 &'-]/g, '').trim() : '';

  // ── Extract Date ──
  const datePatterns = [
    /(\d{2})[\/\-](\d{2})[\/\-](\d{4})/,  // DD/MM/YYYY or DD-MM-YYYY
    /(\d{4})[\/\-](\d{2})[\/\-](\d{2})/,  // YYYY-MM-DD
    /(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})/, // 12 Jan 2024
  ];
  let date = null;
  for (const pattern of datePatterns) {
    const found = text.match(pattern);
    if (found) {
      date = found[0];
      break;
    }
  }

  return {
    amount,
    merchant: merchant.substring(0, 60),
    date,
    rawText: text.substring(0, 500),
  };
}
