const cron = require('node-cron');
const nodemailer = require('nodemailer');
const Budget = require('../models/Budget');
const Expense = require('../models/Expense');
const User = require('../models/User');

// ── Email Transporter ──
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT),
  secure: false,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
});

const sendEmail = async ({ to, subject, html }) => {
  try {
    await transporter.sendMail({ from: process.env.EMAIL_FROM, to, subject, html });
    console.log(`📧 Email sent to ${to}: ${subject}`);
  } catch (err) {
    console.error('Email send error:', err.message);
  }
};

// ── Check budgets every hour ──
const checkBudgetAlerts = async () => {
  try {
    const month = new Date().toISOString().slice(0, 7);
    const budgets = await Budget.find({ month, alertSent: false }).populate('userId categoryId');

    for (const budget of budgets) {
      const user = budget.userId;
      if (!user?.notifPrefs?.budgetAlerts) continue;

      const [year, mon] = month.split('-').map(Number);
      const start = new Date(year, mon - 1, 1);
      const end = new Date(year, mon, 0, 23, 59, 59);

      const agg = await Expense.aggregate([
        { $match: { userId: user._id, categoryId: budget.categoryId._id, date: { $gte: start, $lte: end } } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]);
      const spent = agg[0]?.total || 0;
      const pct = (spent / budget.limit) * 100;

      if (pct >= budget.alertAt) {
        // Mark alert sent to avoid duplicate emails
        await Budget.findByIdAndUpdate(budget._id, { alertSent: true });

        await sendEmail({
          to: user.email,
          subject: `⚠️ Budget Alert: ${budget.categoryId.name} is at ${Math.round(pct)}%`,
          html: budgetAlertTemplate(user.name, budget.categoryId.name, spent, budget.limit, pct, user.currency),
        });
      }
    }
  } catch (err) {
    console.error('Budget alert check error:', err.message);
  }
};

// ── Send weekly digest every Sunday at 9AM ──
const sendWeeklyDigests = async () => {
  try {
    const users = await User.find({ 'notifPrefs.weeklyDigest': true });
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    for (const user of users) {
      const expenses = await Expense.aggregate([
        { $match: { userId: user._id, date: { $gte: sevenDaysAgo } } },
        { $group: { _id: '$categoryId', total: { $sum: '$amount' }, count: { $sum: 1 } } },
        { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'cat' } },
        { $unwind: '$cat' },
        { $sort: { total: -1 } },
      ]);

      if (expenses.length === 0) continue;

      const total = expenses.reduce((s, e) => s + e.total, 0);
      await sendEmail({
        to: user.email,
        subject: `📊 Your Weekly Finance Summary - ${new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`,
        html: weeklyDigestTemplate(user.name, expenses, total, user.currency),
      });
    }
  } catch (err) {
    console.error('Weekly digest error:', err.message);
  }
};

// ── Email Templates ──
const budgetAlertTemplate = (name, category, spent, limit, pct, currency) => `
<!DOCTYPE html>
<html>
<body style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:24px;background:#f8fafc;">
  <div style="background:#fff;border-radius:12px;padding:32px;border:1px solid #e2e8f0;">
    <h2 style="color:#ef4444;margin:0 0 16px;">⚠️ Budget Alert</h2>
    <p style="color:#374151;">Hi <strong>${name}</strong>,</p>
    <p style="color:#374151;">Your <strong>${category}</strong> budget has reached <strong>${Math.round(pct)}%</strong>.</p>
    <div style="background:#fef2f2;border-radius:8px;padding:16px;margin:16px 0;">
      <div style="display:flex;justify-content:space-between;">
        <span style="color:#6b7280;">Spent</span>
        <strong style="color:#ef4444;">${currency} ${spent.toFixed(0)}</strong>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:8px;">
        <span style="color:#6b7280;">Budget limit</span>
        <strong style="color:#374151;">${currency} ${limit.toFixed(0)}</strong>
      </div>
      <div style="background:#fee2e2;border-radius:4px;height:8px;margin-top:12px;">
        <div style="background:#ef4444;height:8px;border-radius:4px;width:${Math.min(pct, 100)}%;"></div>
      </div>
    </div>
    <p style="color:#6b7280;font-size:14px;">Log in to your Finance Assistant to review and adjust your budget.</p>
  </div>
</body>
</html>`;

const weeklyDigestTemplate = (name, expenses, total, currency) => `
<!DOCTYPE html>
<html>
<body style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:24px;background:#f8fafc;">
  <div style="background:#fff;border-radius:12px;padding:32px;border:1px solid #e2e8f0;">
    <h2 style="color:#0f172a;margin:0 0 8px;">📊 Weekly Summary</h2>
    <p style="color:#6b7280;margin:0 0 24px;">Hi ${name}, here's where your money went this week.</p>
    <div style="background:#f0fdf4;border-radius:8px;padding:16px;text-align:center;margin-bottom:24px;">
      <div style="color:#6b7280;font-size:13px;">Total Spent</div>
      <div style="color:#16a34a;font-size:28px;font-weight:700;">${currency} ${total.toFixed(0)}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;">
      ${expenses.map(e => `
        <tr>
          <td style="padding:10px 0;border-bottom:1px solid #f1f5f9;color:#374151;">${e.cat.icon || '📦'} ${e.cat.name}</td>
          <td style="padding:10px 0;border-bottom:1px solid #f1f5f9;text-align:right;font-weight:600;color:#0f172a;">${currency} ${e.total.toFixed(0)}</td>
        </tr>`).join('')}
    </table>
    <p style="color:#6b7280;font-size:13px;margin-top:24px;text-align:center;">Keep tracking to hit your savings goals! 💪</p>
  </div>
</body>
</html>`;

// ── Start all cron jobs ──
exports.startCronJobs = () => {
  // Check budget alerts every hour
  cron.schedule('0 * * * *', checkBudgetAlerts);
  // Send weekly digest every Sunday at 9:00 AM
  cron.schedule('0 9 * * 0', sendWeeklyDigests);
  console.log('⏰ Cron jobs started: budget alerts (hourly) + weekly digest (Sunday 9AM)');
};
