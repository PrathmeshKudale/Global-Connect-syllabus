const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth.middleware');
const chatController = require('../controllers/chat.controller');

router.use(protect);

router.post('/query', chatController.query);

module.exports = router;
