const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth.middleware');
const upload = require('../middleware/upload.middleware');
const expenseController = require('../controllers/expense.controller');

router.use(protect); // All expense routes require authentication

router.get('/',           expenseController.getExpenses);
router.get('/summary',    expenseController.getSummary);
router.post('/',          expenseController.addExpense);
router.post('/voice',     expenseController.parseVoice);
router.post('/receipt',   upload.single('receipt'), expenseController.uploadReceipt);
router.patch('/:id',      expenseController.updateExpense);
router.delete('/:id',     expenseController.deleteExpense);

module.exports = router;
