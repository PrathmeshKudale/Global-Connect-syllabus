// ── budget.routes.js ──
const express = require('express');
const budgetRouter = express.Router();
const { protect } = require('../middleware/auth.middleware');
const Budget = require('../models/Budget');
const Expense = require('../models/Expense');

budgetRouter.use(protect);

// GET /budgets - list all budgets for current month with spend progress
budgetRouter.get('/', async (req, res) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const budgets = await Budget.find({ userId: req.user._id, month }).populate('categoryId');

    // Calculate current spend for each budget category
    const [year, mon] = month.split('-').map(Number);
    const start = new Date(year, mon - 1, 1);
    const end = new Date(year, mon, 0, 23, 59, 59);

    const enriched = await Promise.all(budgets.map(async (b) => {
      const agg = await Expense.aggregate([
        { $match: { userId: req.user._id, categoryId: b.categoryId._id, date: { $gte: start, $lte: end } } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]);
      const spent = agg[0]?.total || 0;
      return { ...b.toObject(), spent, progress: Math.round((spent / b.limit) * 100) };
    }));

    res.json({ budgets: enriched });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /budgets
budgetRouter.post('/', async (req, res) => {
  try {
    const { categoryId, limit, alertAt, rollover, month } = req.body;
    const budget = await Budget.create({ userId: req.user._id, categoryId, limit, alertAt, rollover, month });
    res.status(201).json({ budget: await budget.populate('categoryId') });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ error: 'Budget for this category and month already exists.' });
    res.status(400).json({ error: err.message });
  }
});

// PATCH /budgets/:id
budgetRouter.patch('/:id', async (req, res) => {
  try {
    const budget = await Budget.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      req.body,
      { new: true }
    ).populate('categoryId');
    if (!budget) return res.status(404).json({ error: 'Budget not found.' });
    res.json({ budget });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /budgets/:id
budgetRouter.delete('/:id', async (req, res) => {
  try {
    await Budget.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = budgetRouter;
