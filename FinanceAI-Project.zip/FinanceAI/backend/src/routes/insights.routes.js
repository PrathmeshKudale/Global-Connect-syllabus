const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth.middleware');
const insightsController = require('../controllers/insights.controller');

router.use(protect);

router.get('/',           insightsController.getInsights);
router.get('/anomalies',  insightsController.getAnomalies);
router.get('/trends',     insightsController.getTrends);

module.exports = router;
