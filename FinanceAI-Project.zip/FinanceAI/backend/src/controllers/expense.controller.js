const Expense = require('../models/Expense');
const Category = require('../models/Category');
const { categorizeExpense, parseVoiceTranscript } = require('../services/openai.service');
const { extractReceiptData } = require('../services/ocr.service');

// ── GET /expenses ──
// Supports: ?page=1&limit=20&category=id&from=2024-01-01&to=2024-01-31&search=coffee
exports.getExpenses = async (req, res) => {
  try {
    const { page = 1, limit = 20, category, from, to, search, sort = '-date' } = req.query;

    const filter = { userId: req.user._id };
    if (category) filter.categoryId = category;
    if (from || to) {
      filter.date = {};
      if (from) filter.date.$gte = new Date(from);
      if (to) filter.date.$lte = new Date(new Date(to).setHours(23, 59, 59));
    }
    if (search) {
      filter.$or = [
        { merchant: { $regex: search, $options: 'i' } },
        { note: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Expense.countDocuments(filter);
    const expenses = await Expense.find(filter)
      .populate('categoryId')
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .lean();

    res.json({ data: expenses, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── GET /expenses/summary ──
// Returns per-category totals for a date range (used for charts)
exports.getSummary = async (req, res) => {
  try {
    const { from, to } = req.query;
    const start = from ? new Date(from) : new Date(new Date().setDate(1)); // default: start of month
    const end = to ? new Date(to) : new Date();

    const summary = await Expense.aggregate([
      { $match: { userId: req.user._id, date: { $gte: start, $lte: end } } },
      { $group: { _id: '$categoryId', total: { $sum: '$amount' }, count: { $sum: 1 } } },
      { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'category' } },
      { $unwind: '$category' },
      { $project: { total: 1, count: 1, name: '$category.name', icon: '$category.icon', color: '$category.color' } },
      { $sort: { total: -1 } },
    ]);

    const grandTotal = summary.reduce((sum, s) => sum + s.total, 0);
    res.json({ categories: summary, total: grandTotal, period: { from: start, to: end } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── POST /expenses ──
exports.addExpense = async (req, res) => {
  try {
    let { amount, merchant, categoryId, note, date, source, tags } = req.body;

    // If no category provided, use AI to classify
    if (!categoryId) {
      const categories = await Category.find({ $or: [{ isDefault: true }, { userId: req.user._id }] });
      const aiResult = await categorizeExpense(merchant, note, categories);
      categoryId = aiResult.categoryId;
    }

    const expense = await Expense.create({
      userId: req.user._id,
      amount, merchant, categoryId, note,
      date: date || new Date(),
      source: source || 'manual',
      tags: tags || [],
    });

    res.status(201).json({ expense: await expense.populate('categoryId') });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// ── POST /expenses/voice ──
exports.parseVoice = async (req, res) => {
  try {
    const { transcript } = req.body;
    if (!transcript) return res.status(400).json({ error: 'Transcript is required.' });

    const categories = await Category.find({ $or: [{ isDefault: true }, { userId: req.user._id }] });
    const parsed = await parseVoiceTranscript(transcript, categories);

    res.json({ parsed });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── POST /expenses/receipt ──
exports.uploadReceipt = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No receipt file uploaded.' });

    const extracted = await extractReceiptData(req.file.buffer, req.file.mimetype);
    const categories = await Category.find({ $or: [{ isDefault: true }, { userId: req.user._id }] });
    
    // Use AI to categorise based on extracted merchant name
    let categoryId = null;
    if (extracted.merchant) {
      const aiResult = await categorizeExpense(extracted.merchant, '', categories);
      categoryId = aiResult.categoryId;
    }

    res.json({ parsed: { ...extracted, categoryId }, message: 'Receipt processed. Please confirm before saving.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── PATCH /expenses/:id ──
exports.updateExpense = async (req, res) => {
  try {
    const expense = await Expense.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      req.body,
      { new: true, runValidators: true }
    ).populate('categoryId');
    if (!expense) return res.status(404).json({ error: 'Expense not found.' });
    res.json({ expense });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// ── DELETE /expenses/:id ──
exports.deleteExpense = async (req, res) => {
  try {
    const expense = await Expense.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
    if (!expense) return res.status(404).json({ error: 'Expense not found.' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
