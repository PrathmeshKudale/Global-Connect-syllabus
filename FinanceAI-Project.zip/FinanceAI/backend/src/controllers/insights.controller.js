const Expense = require('../models/Expense');
const { generateInsights, detectAnomalies } = require('../services/openai.service');

// ── GET /insights ──
exports.getInsights = async (req, res) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const [year, mon] = month.split('-').map(Number);
    const start = new Date(year, mon - 1, 1);
    const end = new Date(year, mon, 0, 23, 59, 59);

    // Aggregate spend by category for current month
    const currentSummary = await Expense.aggregate([
      { $match: { userId: req.user._id, date: { $gte: start, $lte: end } } },
      { $group: { _id: '$categoryId', total: { $sum: '$amount' }, count: { $sum: 1 } } },
      { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'cat' } },
      { $unwind: '$cat' },
      { $project: { total: 1, count: 1, name: '$cat.name', icon: '$cat.icon' } },
      { $sort: { total: -1 } },
    ]);

    // Previous month for comparison
    const prevStart = new Date(year, mon - 2, 1);
    const prevEnd = new Date(year, mon - 1, 0, 23, 59, 59);
    const prevSummary = await Expense.aggregate([
      { $match: { userId: req.user._id, date: { $gte: prevStart, $lte: prevEnd } } },
      { $group: { _id: '$categoryId', total: { $sum: '$amount' } } },
    ]);
    const prevMap = Object.fromEntries(prevSummary.map(p => [p._id.toString(), p.total]));

    const totalSpent = currentSummary.reduce((s, c) => s + c.total, 0);

    // Build insights using GPT
    const insights = await generateInsights({
      currentSummary,
      prevMap,
      totalSpent,
      month,
      userName: req.user.name,
      currency: req.user.currency,
    });

    res.json({ insights, summary: currentSummary, totalSpent, month });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── GET /insights/anomalies ──
exports.getAnomalies = async (req, res) => {
  try {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const expenses = await Expense.find({ userId: req.user._id, date: { $gte: thirtyDaysAgo } })
      .populate('categoryId').lean();

    const anomalies = await detectAnomalies(expenses, req.user.currency);
    res.json({ anomalies });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ── GET /insights/trends ──
// Returns weekly totals for the past 12 weeks (for line chart)
exports.getTrends = async (req, res) => {
  try {
    const twelveWeeksAgo = new Date(Date.now() - 12 * 7 * 24 * 60 * 60 * 1000);
    const expenses = await Expense.aggregate([
      { $match: { userId: req.user._id, date: { $gte: twelveWeeksAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%U', date: '$date' } },
          total: { $sum: '$amount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);
    res.json({ trends: expenses });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
