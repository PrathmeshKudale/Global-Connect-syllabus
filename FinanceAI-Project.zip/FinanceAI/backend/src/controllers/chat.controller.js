const Expense = require('../models/Expense');
const { chatWithContext } = require('../services/openai.service');

// ── POST /chat/query ──
exports.query = async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    if (!message) return res.status(400).json({ error: 'Message is required.' });

    // Build financial context for this user (last 90 days)
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const recentExpenses = await Expense.find({
      userId: req.user._id,
      date: { $gte: ninetyDaysAgo },
    }).populate('categoryId').lean();

    // Aggregate by category for context
    const categoryTotals = {};
    recentExpenses.forEach(e => {
      const cat = e.categoryId?.name || 'Other';
      categoryTotals[cat] = (categoryTotals[cat] || 0) + e.amount;
    });

    const totalSpent = recentExpenses.reduce((s, e) => s + e.amount, 0);
    const expenseCount = recentExpenses.length;

    const context = {
      userName: req.user.name,
      currency: req.user.currency,
      totalSpentLast90Days: totalSpent,
      expenseCount,
      categoryBreakdown: categoryTotals,
      recentTransactions: recentExpenses.slice(0, 10).map(e => ({
        amount: e.amount,
        merchant: e.merchant,
        category: e.categoryId?.name,
        date: e.date,
      })),
    };

    const reply = await chatWithContext(message, history, context);
    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
