const mongoose = require('mongoose');

const expenseSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0.01, 'Amount must be positive'],
  },
  currency: {
    type: String,
    default: 'INR',
  },
  merchant: {
    type: String,
    trim: true,
    default: 'Unknown',
  },
  categoryId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true,
  },
  // AI-suggested category name (denormalised for quick display)
  aiCategory: {
    type: String,
    default: null,
  },
  note: {
    type: String,
    trim: true,
    maxlength: [300, 'Note cannot exceed 300 characters'],
    default: '',
  },
  // How was this expense entered?
  source: {
    type: String,
    enum: ['manual', 'voice', 'ocr', 'sms'],
    default: 'manual',
  },
  receiptUrl: {
    type: String,
    default: null,
  },
  date: {
    type: Date,
    required: true,
    default: Date.now,
    index: true,
  },
  tags: {
    type: [String],
    default: [],
  },
  isRecurring: {
    type: Boolean,
    default: false,
  },
}, {
  timestamps: true,
});

// Compound indexes for fast aggregation queries
expenseSchema.index({ userId: 1, date: -1 });
expenseSchema.index({ userId: 1, categoryId: 1 });
expenseSchema.index({ userId: 1, date: -1, categoryId: 1 });

module.exports = mongoose.model('Expense', expenseSchema);
