const mongoose = require('mongoose');

const budgetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  categoryId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true,
  },
  limit: {
    type: Number,
    required: [true, 'Budget limit is required'],
    min: [1, 'Budget must be at least 1'],
  },
  // Percentage at which to send alert (e.g., 80 = alert at 80%)
  alertAt: {
    type: Number,
    default: 80,
    min: 1,
    max: 100,
  },
  // If true, unused budget rolls over to next month
  rollover: {
    type: Boolean,
    default: false,
  },
  // Month in YYYY-MM format
  month: {
    type: String,
    required: true,
    match: [/^\d{4}-\d{2}$/, 'Month must be in YYYY-MM format'],
  },
  // Track if alert has already been sent this month
  alertSent: {
    type: Boolean,
    default: false,
  },
}, { timestamps: true });

budgetSchema.index({ userId: 1, month: 1 });
budgetSchema.index({ userId: 1, categoryId: 1, month: 1 }, { unique: true });

module.exports = mongoose.model('Budget', budgetSchema);
