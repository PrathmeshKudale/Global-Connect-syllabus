const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  icon: { type: String, default: '📦' },
  color: { type: String, default: '#94a3b8' },
  isDefault: { type: Boolean, default: false },
  // null = system default available to all users
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  // Keywords help AI matching
  keywords: { type: [String], default: [] },
}, { timestamps: true });

categorySchema.index({ isDefault: 1 });
categorySchema.index({ userId: 1 });

module.exports = mongoose.model('Category', categorySchema);
